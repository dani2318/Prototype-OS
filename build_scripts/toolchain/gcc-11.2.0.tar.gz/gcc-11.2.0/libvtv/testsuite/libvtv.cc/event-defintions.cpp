#include "event.h"

Event::Event()
{
}

Event::~Event()
{

}
