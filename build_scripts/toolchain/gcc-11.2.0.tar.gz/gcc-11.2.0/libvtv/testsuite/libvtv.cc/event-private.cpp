#include "event-private.h"

PrivateEvent::PrivateEvent()
{
}

PrivateEvent::~PrivateEvent()
{

}
